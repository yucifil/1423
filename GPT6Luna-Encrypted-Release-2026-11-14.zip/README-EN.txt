GPT6Luna encrypted release

Contents
- gpt6luna-encrypted-2026-11-14.svlt: encrypted file.
- SHA256SUMS.txt: integrity checksum.

To decrypt
1. Download this ZIP from the GitHub Release and extract it.
2. Open the GPT6Luna Script Vault tool in a modern browser.
3. Choose decrypt, select the extracted .svlt file (not the ZIP), and enter the password shared with you separately.

Security
- This ZIP contains ciphertext only, not the password. Never upload or commit the password.
- Share the password through a separate trusted channel after verifying the recipient.
- A public GitHub Release is public and can be copied by anyone. Encryption does not prevent analysis after decryption or while a script runs.
- Keep a secure backup of the original and verify the checksum after downloading. The checksum alone does not authenticate the publisher; obtain it separately from a trusted source.
